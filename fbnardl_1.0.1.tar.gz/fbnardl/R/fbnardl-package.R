#' fbnardl: Fourier Bootstrap Nonlinear ARDL
#'
#' @description
#' Implements the Fourier Bootstrap Nonlinear Autoregressive Distributed Lag
#' (FBNARDL) model for analyzing asymmetric cointegration relationships.
#' Combines the NARDL framework of Shin, Yu & Greenwood-Nimmo (2014) with
#' Fourier approximation for smooth structural breaks and optional bootstrap
#' inference.
#'
#' @section Main Function:
#' The main function is \code{\link{fbnardl}}, which estimates the model and
#' returns an object of class "fbnardl" with comprehensive results.
#'
#' @section Features:
#' \itemize{
#'   \item Asymmetric decomposition into positive/negative partial sums
#'   \item Fourier terms for smooth structural breaks
#'   \item Two-step model selection (k* by SSR, lags by AIC/BIC)
#'   \item Analytical or bootstrap critical values for cointegration testing
#'   \item Short-run and long-run multipliers with delta method standard errors
#'   \item Wald tests for asymmetry
#'   \item Comprehensive diagnostic tests
#'   \item Dynamic multiplier visualization
#' }
#'
#' @section References:
#' Shin, Y., Yu, B., & Greenwood-Nimmo, M. (2014). Modelling asymmetric
#' cointegration and dynamic multipliers in a nonlinear ARDL framework.
#' In Festschrift in Honor of Peter Schmidt (pp. 281-314). Springer.
#' \doi{10.1007/978-1-4899-8008-3_9}
#'
#' Pesaran, M. H., Shin, Y., & Smith, R. J. (2001). Bounds testing approaches
#' to the analysis of level relationships. Journal of Applied Econometrics,
#' 16(3), 289-326. \doi{10.1002/jae.616}
#'
#' Yilanci, V., Bozoklu, S., & Gorus, M. S. (2020). Are BRICS countries
#' pollution havens? Evidence from a bootstrap ARDL bounds testing approach
#' with a Fourier function. Sustainable Cities and Society, 55, 102035.
#' \doi{10.1016/j.scs.2020.102035}
#'
#' Kripfganz, S., & Schneider, D. C. (2020). Response surface regressions
#' for critical value bounds and approximate p-values in equilibrium
#' correction models. Oxford Bulletin of Economics and Statistics, 82(6),
#' 1456-1481. \doi{10.1111/obes.12377}
#'
#' @author Dr. Merwan Roudane \email{merwanroudane920@@gmail.com}
#'
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
